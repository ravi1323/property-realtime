# events
  - user:signin
  - user:signin:fail
  - user:signin:success

  - user:signup
  - user:signup:fail
  - user:signup:success
